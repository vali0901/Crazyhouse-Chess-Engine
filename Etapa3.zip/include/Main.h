#include "PlaySide.h"
#ifndef MAIN_H
#define MAIN_H

PlaySide getEngineSide();

#endif