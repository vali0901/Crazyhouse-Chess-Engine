#ifndef MOVE_H
#define MOVE_H

#include <bits/stdc++.h>

#include "Piece.h"

class Move {
 public:
  /* Positions (source, destination_str) are encoded in coordinate notation
   as strings (i.e. "e1", "f6", "a4" etc.) */
  std::optional<std::string> source_str;
  std::optional<std::string> destination_str;
  std::optional<std::pair<int8_t, int8_t>> source_idx;
  std::optional<std::pair<int8_t, int8_t>> destination_idx;
  std::optional<Piece> replacement;

  /*
    Use the following 4 constructors for Move:
    moveTo(src, dst), if emitting a standard move (advance, capture, castle)
    promote(src, dst, replace), if advancing a pawn to last row
    dropIn(dst, replace), if placing a captured piece
    resign(), if you want to resign
   */

  std::optional<std::string> getSource();
  std::optional<std::string> getDestination();
  std::optional<Piece> getReplacement();
  /**
   * Checks whether the move is an usual move/capture
   * @return true if move is NOT a drop-in or promotion, false otherwise
   */
  bool isNormal();
  /**
   * Check whether move is a promotion (pawn advancing to last row)
   * @return true if move is a promotion (promotion field set and source is not
   * null)
   */
  bool isPromotion();
  /**
   * Check whether the move is a crazyhouse drop-in (place a captured enemy
   * piece to fight on your side)
   */
  bool isDropIn();
  /**
   * Emit a move from src to dst. Validity is to be checked by engine (your
   * implementation) Positions are encoded as stated at beginning of file
   * Castles are encoded as follows:
   * source: position of king
   * destination_str: final position of king (two tiles away)
   * @param source initial tile
   * @param destination_str destination_str tile
   * @return move to be sent to board
   */
  static Move moveTo(std::optional<std::string> source,
                      std::optional<std::string> destination);

  static Move moveTo(std::optional<std::pair<int8_t, int8_t>> source,
                      std::optional<std::pair<int8_t, int8_t>> destination);
  /**
   * Emit a promotion move. Validity is to be checked by engine
   * (i.e. source contains a pawn in second to last row, etc.)
   * @param source initial tile of pawn
   * @param destination_str next tile (could be diagonal if also capturing)
   * @param replacement piece to promote to (must not be pawn or king)
   * @return move to be sent to board
   */
  static Move promote(std::optional<std::string> source,
                       std::optional<std::string> destination,
                       std::optional<Piece> replacement);
     static Move promote(std::optional<std::pair<int8_t, int8_t>> source,
                         std::optional<std::pair<int8_t, int8_t>> destination,
                         std::optional<Piece> replacement);
  /**
   * Emit a drop-in (Crazyhouse specific move where player summons
   * a captured piece onto a free tile. Pawns can not be dropped in first and
   * last rows)
   * @param destination_str
   * @param replacement
   * @return
   */
  static Move dropIn(std::optional<std::string> destination,
                      std::optional<Piece> replacement);
  static Move dropIn(std::optional<std::pair<int8_t, int8_t>> destination,
                   std::optional<Piece> replacement);

  static Move resign();

  static void convertStrToIdx(Move &move);
  static void convertIdxToStr(Move &move);
  Move();
 private:
  /* Piece to promote a pawn advancing to last row, or
   *  piece to drop-in (from captured assets) */
  Move(std::optional<std::pair<int8_t, int8_t>> _source,
       std::optional<std::pair<int8_t, int8_t>> _destination,
       std::optional<Piece> _replacement);
  
  Move(std::optional<std::string> _source,
       std::optional<std::string> _destination,
       std::optional<Piece> _replacement);

  
};
#endif
